<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>Login — IDSS UMKM Fuzzy Mamdani</title>
  <!-- Google Font: Inter -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
  <!-- Bootstrap 4 & AdminLTE 3 -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/admin-lte@3.2/dist/css/adminlte.min.css">
  <link rel="stylesheet" href="<?= base_url('assets/css/custom.css') ?>">
  <style>
    * {
      box-sizing: border-box;
    }
    body {
      font-family: 'Inter', -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
      min-height: 100vh;
      margin: 0;
      padding: 1.5rem 1rem;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      position: relative;
      overflow-x: hidden;
      background-color: #0F172A;
    }

    /* 1. LAYER FOTO BERBAGAI JENIS UMKM (JERNIH & SEDIKIT BLUR HALUS) */
    .login-bg-media {
      position: fixed;
      top: -15px;
      left: -15px;
      right: -15px;
      bottom: -15px;
      background-image: url('<?= base_url("assets/img/umkm_background.jpg?v=" . (file_exists(FCPATH . "assets/img/umkm_background.jpg") ? filemtime(FCPATH . "assets/img/umkm_background.jpg") : time())) ?>');
      background-size: cover;
      background-position: center center;
      background-repeat: no-repeat;
      filter: blur(2.5px) brightness(0.74) saturate(1.10);
      transform: scale(1.03); /* Menghilangkan efek tepi blur putih */
      z-index: 0;
      pointer-events: none;
    }

    /* 2. LAYER OVERLAY GRADASI RINGAN AGAR FOTO TETAP JELAS & TEKS KONTRAS */
    .login-bg-overlay {
      position: fixed;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      background: radial-gradient(circle at 50% 45%, rgba(15, 23, 42, 0.18) 0%, rgba(10, 25, 55, 0.62) 100%);
      z-index: 1;
      pointer-events: none;
    }

    /* 3. KONTEN UTAMA LOGIN (GLASSMORPHISM MODERN) */
    .login-container {
      position: relative;
      z-index: 2;
      width: 100%;
      max-width: 450px;
      margin: auto;
    }

    .login-card {
      background: rgba(255, 255, 255, 0.96);
      backdrop-filter: blur(20px);
      -webkit-backdrop-filter: blur(20px);
      border-radius: 20px;
      border: 1px solid rgba(255, 255, 255, 0.45);
      box-shadow: 0 25px 60px -15px rgba(0, 0, 0, 0.55), 0 0 0 1px rgba(255, 255, 255, 0.25);
      overflow: hidden;
      transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
    }

    .login-card:hover {
      box-shadow: 0 30px 70px -15px rgba(0, 0, 0, 0.65), 0 0 0 1px rgba(255, 255, 255, 0.35);
      transform: translateY(-2px);
    }

    .login-card-header {
      background: linear-gradient(135deg, #1E3A8A 0%, #2563EB 55%, #1D4ED8 100%);
      color: #FFFFFF;
      padding: 2.25rem 2rem 1.75rem 2rem;
      text-align: center;
      position: relative;
      overflow: hidden;
    }

    .login-card-header::after {
      content: '';
      position: absolute;
      top: -50%;
      left: -50%;
      width: 200%;
      height: 200%;
      background: radial-gradient(circle, rgba(255, 255, 255, 0.15) 0%, transparent 60%);
      pointer-events: none;
    }

    .brand-icon-wrap {
      width: 68px;
      height: 68px;
      background: rgba(255, 255, 255, 0.18);
      border: 2px solid rgba(255, 255, 255, 0.35);
      border-radius: 50%;
      margin: 0 auto 12px;
      display: flex;
      align-items: center;
      justify-content: center;
      box-shadow: 0 8px 24px rgba(0, 0, 0, 0.2);
      backdrop-filter: blur(6px);
      transition: transform 0.3s ease;
    }

    .brand-icon-wrap:hover {
      transform: scale(1.08) rotate(5deg);
    }

    .login-card-body {
      padding: 2rem 2.25rem;
    }

    .form-control {
      border-radius: 10px;
      border: 1px solid #CBD5E1;
      padding: 0.65rem 0.9rem;
      font-size: 0.95rem;
      transition: all 0.2s ease;
    }

    .form-control:focus {
      border-color: #2563EB;
      box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.18);
    }

    .input-group-text {
      border-radius: 10px;
      border: 1px solid #CBD5E1;
      background-color: #F8FAFC;
    }

    .btn-login {
      background: linear-gradient(135deg, #2563EB 0%, #1D4ED8 100%);
      border: none;
      color: #FFFFFF;
      font-weight: 700;
      font-size: 1rem;
      padding: 0.8rem 1.25rem;
      border-radius: 10px;
      box-shadow: 0 4px 14px rgba(37, 99, 235, 0.4);
      transition: all 0.25s ease;
      letter-spacing: 0.2px;
    }

    .btn-login:hover {
      background: linear-gradient(135deg, #1D4ED8 0%, #1E3A8A 100%);
      box-shadow: 0 6px 20px rgba(37, 99, 235, 0.6);
      transform: translateY(-1px);
      color: #FFFFFF;
    }

    .btn-login:active {
      transform: translateY(0);
      box-shadow: 0 2px 8px rgba(37, 99, 235, 0.4);
    }

    .cred-badge {
      cursor: pointer;
      display: inline-block;
      padding: 4px 9px;
      margin: 2px 3px 2px 0;
      border-radius: 6px;
      background: #FFFFFF;
      border: 1px solid #E2E8F0;
      color: #1E293B;
      font-size: 0.78rem;
      transition: all 0.15s ease;
      user-select: none;
    }

    .cred-badge:hover {
      background: #EFF6FF;
      border-color: #93C5FD;
      color: #1D4ED8;
      transform: translateY(-1px);
    }

    .cred-badge i {
      color: #2563EB;
    }

    .footer-pill {
      margin-top: 1.25rem;
      text-align: center;
      color: rgba(255, 255, 255, 0.85);
      font-size: 0.8rem;
      text-shadow: 0 2px 4px rgba(0, 0, 0, 0.4);
    }
  </style>
</head>
<body>

<!-- 1. Background Gambar UMKM (Blur & Saturate) -->
<div class="login-bg-media"></div>

<!-- 2. Background Gradient Overlay -->
<div class="login-bg-overlay"></div>

<!-- 3. Form Login Container -->
<div class="login-container">
  <div class="login-card">
    
    <!-- Header Kartu Login -->
    <div class="login-card-header">
      <div class="brand-icon-wrap">
        <i class="fas fa-brain fa-2x text-white"></i>
      </div>
      <h3 class="font-weight-bold mb-1" style="letter-spacing: -0.5px;">IDSS UMKM</h3>
      <p class="text-light mb-0 small" style="opacity: 0.92; font-weight: 400; line-height: 1.4;">
        Model Penalaran Fuzzy Mamdani untuk Evaluasi Kelayakan Usaha UMKM
      </p>
    </div>

    <!-- Body Kartu Login -->
    <div class="login-card-body">
      
      <?php if ($this->session->flashdata('error')): ?>
        <div class="alert alert-danger py-2 px-3 small mb-3 border-0 shadow-sm" style="border-radius: 8px;">
          <i class="fas fa-exclamation-circle mr-1"></i> <?= $this->session->flashdata('error') ?>
        </div>
      <?php endif; ?>

      <?php if ($this->session->flashdata('success')): ?>
        <div class="alert alert-success py-2 px-3 small mb-3 border-0 shadow-sm" style="border-radius: 8px;">
          <i class="fas fa-check-circle mr-1"></i> <?= $this->session->flashdata('success') ?>
        </div>
      <?php endif; ?>

      <?= form_open('login') ?>
        
        <!-- Field Username -->
        <div class="form-group mb-3">
          <label class="text-xs font-weight-bold text-muted text-uppercase" style="letter-spacing: 0.5px;">Username</label>
          <div class="input-group">
            <input type="text" name="username" id="usernameInput" class="form-control" placeholder="Masukkan username Anda" value="<?= set_value('username') ?>" required autofocus>
            <div class="input-group-append">
              <div class="input-group-text"><i class="fas fa-user text-muted"></i></div>
            </div>
          </div>
          <?= form_error('username', '<small class="text-danger">', '</small>') ?>
        </div>

        <!-- Field Password dengan Toggle Visibility -->
        <div class="form-group mb-4">
          <label class="text-xs font-weight-bold text-muted text-uppercase" style="letter-spacing: 0.5px;">Password</label>
          <div class="input-group">
            <input type="password" name="password" id="passwordInput" class="form-control" placeholder="Masukkan password Anda" required>
            <div class="input-group-append">
              <button class="btn btn-outline-secondary input-group-text" type="button" id="togglePasswordBtn" onclick="togglePasswordVisibility()" title="Tampilkan/Sembunyikan Password" style="border-left: 0;">
                <i class="fas fa-eye text-muted" id="toggleIcon"></i>
              </button>
            </div>
          </div>
          <?= form_error('password', '<small class="text-danger">', '</small>') ?>
        </div>

        <!-- Tombol Masuk -->
        <button type="submit" class="btn btn-login btn-block shadow-sm">
          <i class="fas fa-sign-in-alt mr-2"></i> Masuk ke Sistem
        </button>

      <?= form_close() ?>

      <!-- Akun Pengujian Sistem (Satu Kali Klik untuk Isi Form) -->
      <div class="mt-4 pt-3 border-top text-left">
        <div class="d-flex justify-content-between align-items-center mb-2">
          <span class="text-xs font-weight-bold text-muted text-uppercase" style="letter-spacing: 0.5px;">
            <i class="fas fa-key text-warning mr-1"></i> Klik untuk Isi Cepat:
          </span>
          <small class="text-muted text-xs">Akun Uji Coba</small>
        </div>
        <div class="bg-light p-2 rounded small border text-muted">
          <div class="d-flex align-items-center justify-content-between mb-1">
            <span><strong>Administrator:</strong></span>
            <span class="cred-badge" onclick="fillCredentials('admin', 'Admin#2026!')" title="Klik untuk gunakan akun Admin">
              <i class="fas fa-bolt mr-1"></i> <code>admin</code> (Penuh)
            </span>
          </div>
          <div class="d-flex align-items-center justify-content-between">
            <span><strong>Operator Evaluasi:</strong></span>
            <span class="cred-badge" onclick="fillCredentials('operator', 'Operator#2026!')" title="Klik untuk gunakan akun Operator">
              <i class="fas fa-bolt mr-1"></i> <code>operator</code>
            </span>
          </div>
        </div>
      </div>

    </div>
  </div>

  <!-- Footer Keterangan Sistem -->
  <div class="footer-pill">
    <span><i class="fas fa-shield-alt mr-1"></i> Intelligent Decision Support System &bull; Fuzzy Mamdani v1.0</span>
  </div>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
// Toggle Password Visibility
function togglePasswordVisibility() {
  var pwd = document.getElementById('passwordInput');
  var icon = document.getElementById('toggleIcon');
  if (pwd.type === 'password') {
    pwd.type = 'text';
    icon.classList.remove('fa-eye');
    icon.classList.add('fa-eye-slash');
  } else {
    pwd.type = 'password';
    icon.classList.remove('fa-eye-slash');
    icon.classList.add('fa-eye');
  }
}

// Fungsi Isi Cepat Kredensial Pengujian
function fillCredentials(user, pass) {
  document.getElementById('usernameInput').value = user;
  document.getElementById('passwordInput').value = pass;
  document.getElementById('usernameInput').focus();
}
</script>
</body>
</html>
